
public class Apartamento extends Inmueble {
    private int numeroPiso;

    public Apartamento(int codigo, String ciudad, String direccion, double area, double valormetrocuadrado, double valorarriendomensual, int numeroPiso) {
        super(codigo, ciudad, direccion, area, valormetrocuadrado, valorarriendomensual);
        this.numeroPiso = numeroPiso;
    }

    public int getNumeroPiso() {
        return numeroPiso;
    }

    public void setNumeroPiso(int numeroPiso) {
        this.numeroPiso = numeroPiso;
    }
}
