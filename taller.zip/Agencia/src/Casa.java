
public class Casa extends Inmueble {
    private int numeroHabitaciones;

    public Casa(int codigo, String ciudad, String direccion, double area, double valormetrocuadrado, double valorarriendomensual, int numeroHabitaciones) {
        super(codigo, ciudad, direccion, area, valormetrocuadrado, valorarriendomensual);
        this.numeroHabitaciones = numeroHabitaciones;
    }

    public int getNumeroHabitaciones() {
        return numeroHabitaciones;
    }

    public void setNumeroHabitaciones(int numeroHabitaciones) {
        this.numeroHabitaciones = numeroHabitaciones;
    }
}
